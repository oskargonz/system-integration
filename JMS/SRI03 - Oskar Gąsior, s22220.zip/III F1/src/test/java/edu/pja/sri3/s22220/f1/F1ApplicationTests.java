package edu.pja.sri3.s22220.f1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class F1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
