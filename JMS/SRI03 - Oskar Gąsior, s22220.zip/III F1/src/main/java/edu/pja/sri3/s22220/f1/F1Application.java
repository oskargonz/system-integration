package edu.pja.sri3.s22220.f1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class F1Application {

    public static void main(String[] args) {
        SpringApplication.run(F1Application.class, args);
    }

}
